BACCARAT LIVE ANALYZER — prototype source 0.2.1

Included:
- Android MediaProjection screen capture after explicit user consent.
- Foreground service and floating overlay.
- On-device ML Kit OCR for visible full words BANKER / PLAYER / TIE.
- Local OCR event log at app-private files/ocr_history.txt.
- GitHub Actions workflow to build and publish the debug APK as an artifact.

Important limitations:
- This is NOT a verified Baccarat board reader. It does not classify colored circles / road cells.
- OCR can miss results or read unrelated labels. Verify every reading manually.
- It does not predict future outcomes, automate betting, access site APIs, or guarantee wins.
- Screen capture is visible to Android and can be stopped by the user.

Build requirements:
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Kotlin plugin 2.0.21

Build locally with:
    gradle :app:assembleDebug

Or push this project to GitHub (main/master) and open Actions. The workflow builds
app/build/outputs/apk/debug/app-debug.apk and uploads it as the artifact
"BaccaratLiveAnalyzer-debug-apk".

The current execution environment does not include Android SDK/Gradle, so this
source has not been compiled or device-tested here.
