package com.example.baccaratlive

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var bubble: TextView? = null
    private var windowManager: WindowManager? = null
    private val busy = AtomicBoolean(false)
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private var lastSignature = ""
    private var lastProcessedAt = 0L
    private val history = mutableListOf<String>()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY
        createChannel()
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Baccarat Live Analyzer")
            .setContentText("Đang phân tích màn hình bạn đã cho phép chia sẻ")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED)
            ?: return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra("projectionData", Intent::class.java)
        else intent.getParcelableExtra("projectionData")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, null)
        showBubble()
        startCapture()
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Screen analysis", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun startCapture() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "BaccaratLiveAnalyzer", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null
        )
        reader?.setOnImageAvailableListener({ source ->
            val now = System.currentTimeMillis()
            if (now - lastProcessedAt < 1100) {
                val skipped = source.acquireLatestImage()
                skipped?.close()
                return@setOnImageAvailableListener
            }
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (!busy.compareAndSet(false, true)) {
                image.close()
                return@setOnImageAvailableListener
            }
            lastProcessedAt = now
            processFrame(image)
        }, null)
    }

    private fun processFrame(image: Image) {
        var frameBitmap: Bitmap? = null
        try {
            val bitmap = image.toBitmapWithStride()
            frameBitmap = bitmap
            image.close()
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { result ->
                    val tokens = result.text.uppercase(Locale.ROOT)
                        .split(Regex("[^A-Z]+"))
                        .filter { it in setOf("BANKER", "PLAYER", "TIE") }
                    if (tokens.isNotEmpty()) {
                        val signature = tokens.takeLast(12).joinToString("|")
                        if (signature != lastSignature) {
                            lastSignature = signature
                            val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                            val line = "$time  ${tokens.takeLast(6).joinToString(" / ")}"
                            history.add(line)
                            if (history.size > 12) history.removeAt(0)
                            saveHistory(line)
                            updateBubble()
                        }
                    }
                }
                .addOnFailureListener {
                    bubble?.post { bubble?.text = overlayText("Không đọc được chữ trên khung hình") }
                }
                .addOnCompleteListener {
                    frameBitmap?.recycle()
                    busy.set(false)
                }
        } catch (_: Exception) {
            try { image.close() } catch (_: Exception) {}
            frameBitmap?.recycle()
            busy.set(false)
        }
    }

    private fun Image.toBitmapWithStride(): Bitmap {
        val plane = planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width
        val paddedWidth = width + rowPadding / pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(plane.buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
        padded.recycle()
        return cropped
    }

    private fun showBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        bubble = TextView(this).apply {
            text = overlayText("Đang chờ chữ BANKER / PLAYER / TIE")
            textSize = 12.5f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xE6202633.toInt())
            setPadding(18, 14, 18, 14)
        }
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 170 }
        windowManager?.addView(bubble, params)
    }

    private fun overlayText(message: String): String {
        val recent = history.takeLast(5).joinToString("\n")
        return "BACCARAT LIVE · OCR\n$message\n\nLỊCH SỬ NHẬN DIỆN\n${if (recent.isBlank()) "Chưa có kết quả" else recent}\n\nBản thử nghiệm — hãy đối chiếu thủ công"
    }

    private fun updateBubble() {
        bubble?.post { bubble?.text = overlayText("Đã cập nhật dữ liệu nhận diện") }
    }

    private fun saveHistory(line: String) {
        try {
            File(filesDir, "ocr_history.txt").appendText(line + "\n")
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        reader?.setOnImageAvailableListener(null, null)
        display?.release()
        reader?.close()
        projection?.stop()
        try { bubble?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        recognizer.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL = "baccarat_screen_capture"
        private const val NOTIFICATION_ID = 7
    }
}
