package com.example.baccaratlive

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val requestCapture = 41
    private val requestNotifications = 42
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 40, 28, 28)
            setBackgroundColor(0xFFF5F6FA.toInt())
        }
        val heading = TextView(this).apply {
            text = "BACCARAT LIVE ANALYZER"
            textSize = 22f
            setTextColor(0xFF172033.toInt())
        }
        status = TextView(this).apply {
            text = "Phiên bản thử nghiệm 0.2\\n\\nỨng dụng đọc văn bản hiển thị trên màn hình bạn chủ động chia sẻ và hiện kết quả OCR trong cửa sổ nổi.\\n\\nLưu ý: hiện chưa nhận diện chắc chắn các chấm màu B/P/T trên Big Road."
            textSize = 15f
            setTextColor(0xFF303846.toInt())
            setPadding(0, 20, 0, 20)
        }
        layout.addView(heading)
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "1. Cấp quyền hiển thị trên ứng dụng khác"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else status.text = "Đã cấp quyền cửa sổ nổi. Tiếp tục bước 2."
            }
        })
        layout.addView(Button(this).apply {
            text = "2. Bắt đầu theo dõi màn hình"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    status.text = "Bạn cần cấp quyền cửa sổ nổi trước."
                } else {
                    if (Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), requestNotifications)
                    }
                    val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "3. Dừng theo dõi"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "Đã gửi lệnh dừng theo dõi."
            }
        })
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val serviceIntent = Intent(this, CaptureService::class.java).apply {
                    putExtra("resultCode", resultCode)
                    putExtra("projectionData", data)
                }
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent)
                else startService(serviceIntent)
                status.text = "Đang chia sẻ màn hình. Muốn dừng, quay lại ứng dụng và chọn Dừng theo dõi."
            } else {
                status.text = "Bạn đã hủy quyền chia sẻ màn hình."
            }
        }
    }
}
