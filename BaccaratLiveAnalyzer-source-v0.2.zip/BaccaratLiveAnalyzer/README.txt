BACCARAT LIVE ANALYZER — prototype source 0.2

What is included:
- Android MediaProjection screen capture after explicit user consent.
- Foreground service and a small floating overlay.
- On-device ML Kit text recognition for visible full words BANKER / PLAYER / TIE.
- A simple local text log of recognized OCR events.

Important limitations:
- This is NOT a finished, verified Baccarat board reader. XX88's history board appears to use colored circles/road cells; generic OCR cannot reliably classify those circles.
- The overlay only reports full text tokens that OCR sees. It can miss results or read unrelated labels. Verify every reading manually.
- No prediction of future outcomes, no betting automation, no site/API access, and no guarantee of winning.
- Screen capture is visible to Android and can be stopped by the user/system.

Build requirements:
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3
- Kotlin plugin 2.0.21

Open this folder as a Gradle project in Android Studio or a compatible Android IDE, then run:
    :app:assembleDebug

Expected APK:
    app/build/outputs/apk/debug/app-debug.apk

This environment does not include Android SDK/Gradle, so an APK has not been compiled or device-tested here.
